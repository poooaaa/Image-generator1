// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  vite: {
    server: {
      allowedHosts: true,
      proxy: {
        "^/api/lexica-feed": {
          target: "https://lexica.art",
          changeOrigin: true,
          rewrite: () => "/",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          },
        },
        "^/api/bing-feed": {
          target: "https://www.bing.com",
          changeOrigin: true,
          rewrite: (path) => {
            const queryIndex = path.indexOf("?");
            const query = queryIndex !== -1 ? path.slice(queryIndex) : "";
            const searchParams = new URLSearchParams(query);
            const seed = searchParams.get("seed") || "1";
            const offset = searchParams.get("offset") || "1";
            return `/images/create/async/categoryfeedpage?category=all&seed=${seed}&pageOffset=${offset}&language=en`;
          },
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          },
        },
      },
    },
    preview: {
      allowedHosts: true,
      proxy: {
        "^/api/lexica-feed": {
          target: "https://lexica.art",
          changeOrigin: true,
          rewrite: () => "/",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          },
        },
        "^/api/bing-feed": {
          target: "https://www.bing.com",
          changeOrigin: true,
          rewrite: (path) => {
            const queryIndex = path.indexOf("?");
            const query = queryIndex !== -1 ? path.slice(queryIndex) : "";
            const searchParams = new URLSearchParams(query);
            const seed = searchParams.get("seed") || "1";
            const offset = searchParams.get("offset") || "1";
            return `/images/create/async/categoryfeedpage?category=all&seed=${seed}&pageOffset=${offset}&language=en`;
          },
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          },
        },
      },
    },
  },
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
});
