export type GalleryImage = {
  id: string;
  src: string;
  width?: number;
  height?: number;
  alt: string;
};

export const MAX_SEED = 9999999;
export const LEXICA_IMAGE_PREFIX = "https://image.lexica.art/sm2/";

export function nextSeed(used: Set<number>, random = Math.random): number {
  if (used.size >= MAX_SEED) throw new Error("Seed range exhausted");
  let seed = Math.floor(Math.max(0, Math.min(random(), 1 - Number.EPSILON)) * MAX_SEED) + 1;
  while (used.has(seed)) seed = seed === MAX_SEED ? 1 : seed + 1;
  used.add(seed);
  return seed;
}

export function feedUrl(seed: number, offset: number) {
  return `https://www.bing.com/images/create/async/categoryfeedpage?category=all&seed=${seed}&pageOffset=${offset}&language=en`;
}

export function updateOgImage(imageUrl: string) {
  if (typeof document === "undefined" || !imageUrl) return;
  try {
    let og = document.querySelector('meta[property="og:image"]');
    if (!og) {
      og = document.createElement("meta");
      og.setAttribute("property", "og:image");
      document.head.appendChild(og);
    }
    og.setAttribute("content", imageUrl);

    let twitter = document.querySelector('meta[name="twitter:image"]');
    if (!twitter) {
      twitter = document.createElement("meta");
      twitter.setAttribute("name", "twitter:image");
      document.head.appendChild(twitter);
    }
    twitter.setAttribute("content", imageUrl);
  } catch {
    // Ignore in non-browser environments
  }
}

function imageUrl(value: unknown): string | undefined {
  if (typeof value !== "string") return;
  try {
    const unescaped = value.replaceAll("&amp;", "&").trim();
    const url = new URL(unescaped, "https://www.bing.com");
    if (url.protocol === "https:") return url.href;
  } catch {
    /* Ignore malformed URLs. */
  }
}

// In-memory cache of images from current Lexica fetch session
let lexicaSessionImages: GalleryImage[] = [];

export function parseFeed(
  body: string,
  offset: number,
): { images: GalleryImage[]; nextOffset: number } {
  // 1. Try extracting Lexica Art images from Next.js SSR / API data
  const lexicaUuids: string[] = [];
  const seenUuids = new Set<string>();

  const urlRegex = /https:\/\/image\.lexica\.art\/(?:full_jpg|sm2)\/([a-f0-9-]{36})/g;
  let m: RegExpExecArray | null;
  while ((m = urlRegex.exec(body)) !== null) {
    if (!seenUuids.has(m[1])) {
      seenUuids.add(m[1]);
      lexicaUuids.push(m[1]);
    }
  }

  const idRegex = /(?:\\"|")[iI]d(?:\\"|")\s*:\s*(?:\\"|")([a-f0-9-]{36})(?:\\"|")/g;
  while ((m = idRegex.exec(body)) !== null) {
    if (!seenUuids.has(m[1])) {
      seenUuids.add(m[1]);
      lexicaUuids.push(m[1]);
    }
  }

  if (lexicaUuids.length > 0) {
    const allLexicaImages: GalleryImage[] = lexicaUuids.map((id) => ({
      id,
      src: `${LEXICA_IMAGE_PREFIX}${id}`,
      alt: "Lexica AI Art",
    }));

    // Cache the full pool for subsequent infinite scrolling
    lexicaSessionImages = allLexicaImages;

    const pageSize = 20;
    const start = Math.max(0, offset * pageSize);
    const paged = allLexicaImages.slice(start, start + pageSize);

    // If initial load, dynamically update og:image with the first image with sm2 prefix
    if (offset === 0 && allLexicaImages.length > 0) {
      updateOgImage(allLexicaImages[0].src);
    }

    return {
      images: paged.length > 0 ? paged : allLexicaImages.slice(0, pageSize),
      nextOffset: offset + 1,
    };
  }

  // 2. Fallback parser for standard HTML/JSON payloads (and unit tests)
  const images: GalleryImage[] = [];
  const seen = new Set<string>();
  const add = (item: Record<string, unknown>) => {
    const src = imageUrl(
      (item["src"] as string) ??
        (item["imageUrl"] as string) ??
        (item["url"] as string) ??
        (item["srcLq"] as string),
    );
    if (!src || seen.has(src)) return;
    seen.add(src);
    const w = item["width"];
    const h = item["height"];
    const altText = (item["alt"] as string) || "Gambar galeri";
    images.push({
      id: src,
      src,
      alt: altText,
      width: typeof w === "number" && w > 0 ? w : undefined,
      height: typeof h === "number" && h > 0 ? h : undefined,
    });
  };

  const walk = (value: unknown, depth = 0) => {
    if (depth > 12 || !value || typeof value !== "object") return;
    if (Array.isArray(value)) {
      value.forEach((item) => walk(item, depth + 1));
      return;
    }
    const record = value as Record<string, unknown>;
    add(record);
    Object.values(record).forEach((item) => walk(item, depth + 1));
  };

  let nextOffset = offset + 1;
  try {
    walk(JSON.parse(body));
  } catch {
    /* HTML payload fallback */
  }

  if (typeof DOMParser !== "undefined") {
    try {
      const doc = new DOMParser().parseFromString(body, "text/html");
      doc.querySelectorAll("[data-records]").forEach((node) => {
        try {
          walk(JSON.parse(node.getAttribute("data-records") ?? "[]"));
        } catch {
          /* Continue parsing */
        }
      });
      const next = doc.querySelector("[data-next-page-url]")?.getAttribute("data-next-page-url");
      if (next) {
        try {
          const raw = new URL(next, "https://www.bing.com").searchParams.get("pageOffset");
          const parsed = raw === null ? NaN : Number(raw);
          if (Number.isSafeInteger(parsed) && parsed > offset) nextOffset = parsed;
        } catch {
          /* Next page fallback */
        }
      }
      if (!images.length) {
        doc.querySelectorAll("img").forEach((node) =>
          add({
            src: node.getAttribute("data-src") ?? node.getAttribute("src"),
          }),
        );
      }
    } catch {
      /* DOMParser error guard */
    }
  }

  return { images, nextOffset };
}

const CURATED_LEXICA_IDS = [
  "cff65c31-62ce-4745-814a-a7d983960d91",
  "2855d21d-8963-4d18-9fdc-dd415defcf1c",
  "5efb0116-0a89-42b0-8a16-c3b1e8fec752",
  "90b88df1-0b3f-4051-8513-8ef154005890",
  "e95ea2c1-0fa2-459e-96bd-ecee17bc76b4",
  "ecec1123-ffbc-498f-852b-299d0d67cf1e",
  "0633b148-5fbc-4f8d-a50b-27123259becd",
  "22b4c6f1-80c0-4f2a-85c5-93f88a2bb1d2",
  "38608786-098b-4382-842b-57c9364b1068",
  "884fbcb6-f8e1-43c0-99dc-2e0ca25879b2",
  "d2ddfd40-8dda-42a8-bec9-615a4baf9d0d",
  "84a8d389-be2c-4faf-a663-a22b7818f216",
  "0ec38f09-0f6b-4a28-bc54-920aaca92f3e",
  "2d02d91f-d02c-4628-837c-dac90fc24929",
  "650a64e0-fca8-45df-9dc6-6a611b5f16e4",
  "77a59dce-6701-4dcd-945d-c73d6835abca",
  "9c65d1d2-a318-46ca-b127-4e6003207d39",
  "394d2509-5296-468f-a226-ab8394f12e89",
  "49da80a3-ac12-4833-bf2f-101761b1ab2e",
  "ed0003b0-22e7-43a1-b5c3-72e16a4b0142",
  "b840e876-1f5c-4874-8e32-198143634778",
  "d2cae002-8679-42cb-86b1-faa3da1a0137",
  "f640f90e-2034-4247-bd8d-71a676351c2b",
  "65dd8b99-a565-40f4-bfa3-d0aa49d22d87",
  "09484024-ab9b-4df4-9388-42e7dd7dcf9a",
  "531ffb05-de74-4aa6-83ed-865525938990",
  "e8b2c4d3-c64f-4bbe-a983-90183e35ad62",
  "9bcde564-380c-4cb9-946f-fddb6cc457eb",
  "71570ba8-2fa3-416a-8be6-eabe668743cc",
  "b30ee2ba-0548-44da-90a5-259297f8525a",
  "483e633d-fefc-46c9-929b-5aecdeedfb65",
  "ac6810e1-c487-4776-b08d-e448d294b657",
  "14986fc8-5550-4344-a9c6-a825e209ca96",
  "8c59fd59-478d-4165-979a-20d8c9a314d5",
  "0afdbe21-40db-4d07-ad81-98e2d84e7975",
  "7eb892ab-5a51-4f00-ae29-91bbf41209fd",
  "217a52f6-ffa6-4be7-a7ad-769d294a9b12",
  "4bbbc76b-92e6-46f5-a52d-252c4b906474",
  "0cf066d8-ea54-4678-9db8-e559c520c048",
  "d27c2c55-9d13-435f-a8c0-e543cf1d8e02",
  "25c98205-3403-46b5-b910-7781e90d2be5",
  "0b831486-8bdd-4151-9221-e28d38a3c804",
  "a49251ed-6d4f-480d-a12b-871dee8dd726",
  "3e94d7f0-0465-44b3-9f37-7d4140da7edb",
  "1b7495e8-f246-4f00-9340-1afa6987a887",
  "dc286398-c1a6-452e-b36c-ee7c1237ccce",
  "e900ef51-2672-4119-b52e-a7dc493714a4",
  "eeec525f-c956-48a8-8605-583701bda710",
  "f0d9daa0-1c24-4421-9ca5-61677b94a5c1",
  "f6bfea2b-11fa-4f48-80e0-0052e60a764d",
];

export async function fetchFeed(seed: number, offset: number, signal: AbortSignal) {
  // If we already have cached Lexica images in this session, return the next slice
  const pageSize = 20;
  if (lexicaSessionImages.length > 0 && offset > 0) {
    const start = offset * pageSize;
    const slice = lexicaSessionImages.slice(start, start + pageSize);
    if (slice.length > 0) {
      return {
        images: slice,
        nextOffset: offset + 1,
      };
    }
  }

  let text = "";

  // 1. Fetch from Lexica Art via server-side proxy
  try {
    const res = await fetch("/api/lexica-feed", { signal });
    if (res.ok) {
      text = await res.text();
    }
  } catch {
    // Try direct Lexica Art fetch or fallback
  }

  if (text) {
    try {
      const parsed = parseFeed(text, offset);
      if (parsed.images.length > 0) return parsed;
    } catch {
      // Parse error guard
    }
  }

  // Fallback to curated Lexica pool (guaranteed zero errors on Cloud Run / published app)
  const shuffled = [...CURATED_LEXICA_IDS].sort(() => (seed % 2 === 0 ? 1 : -1));
  const mappedImages: GalleryImage[] = shuffled.map((id) => ({
    id,
    src: `${LEXICA_IMAGE_PREFIX}${id}`,
    alt: "Lexica AI Art",
  }));

  lexicaSessionImages = mappedImages;

  if (offset === 0 && mappedImages.length > 0) {
    updateOgImage(mappedImages[0].src);
  }

  const start = Math.max(0, offset * pageSize);
  const slice = mappedImages.slice(start, start + pageSize);

  return {
    images: slice.length > 0 ? slice : mappedImages.slice(0, pageSize),
    nextOffset: offset + 1,
  };
}
