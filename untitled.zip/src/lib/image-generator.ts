export const API_URL = "https://ai-image.pooo79886.workers.dev";
export const DEFAULT_API_KEY = "12345678";

export type GeneratedImage = {
  id: string;
  url: string;
  prompt: string;
  createdAt: number;
};

export async function generateImage(
  prompt: string,
  apiKey = DEFAULT_API_KEY,
  signal?: AbortSignal,
): Promise<{ url: string; blob: Blob }> {
  const trimmed = prompt.trim();
  if (!trimmed) {
    throw new Error("Masukkan deskripsi gambar terlebih dahulu");
  }

  // 1. Try direct fetch from Cloudflare Worker
  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ prompt: trimmed }),
      signal,
    });

    if (!res.ok) {
      throw new Error(`API Error (${res.status})`);
    }

    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    return { url, blob };
  } catch (directErr: unknown) {
    if (signal?.aborted) throw directErr;
    const directMessage = directErr instanceof Error ? directErr.message : undefined;
    // 2. Fall back to local server-side proxy
    try {
      const proxyRes = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({ prompt: trimmed }),
        signal,
      });

      if (!proxyRes.ok) {
        throw new Error(`API Error (${proxyRes.status})`);
      }

      const blob = await proxyRes.blob();
      const url = URL.createObjectURL(blob);
      return { url, blob };
    } catch {
      throw new Error(directMessage || "Gagal membuat gambar. Silakan coba lagi.");
    }
  }
}

export const GROQ_API_KEY = "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";

export const ENHANCE_SYSTEM_PROMPT = `You are a master AI image prompt director. Transform the user's idea into a vivid, visually obedient English prompt for AI image generators.

CRITICAL RULES:
1. ACTION & DYNAMICS ENFORCEMENT (ANTI-STUBBORNNESS):
   - AI image models stubbornly default to mundane resting poses (e.g., parking vehicles on pavement, characters standing idly).
   - If the user specifies any dynamic, fantastical, or counter-intuitive state (e.g., flying, hovering, floating, levitating, submerged, soaring, defying gravity, massive or miniature scale), you MUST forcefully command this state in the VERY FIRST sentence.
   - For flying/hovering subjects: Explicitly describe them airborne in mid-flight with wide empty space beneath, zero ground contact, wheels or feet completely suspended in air, and a small cast shadow on the distant terrain below to cement vertical clearance.
2. RESPECT CORE SUBJECT & IDENTITY:
   - Preserve iconic colors and shapes (e.g., a school bus is classic yellow) unless instructed otherwise.
   - Accurately translate Indonesian or any language into clear, descriptive English.
3. ZERO BUZZWORD SLOP:
   - Do NOT use empty filler words like "8k", "photorealistic", "hyperrealistic", "octane render", "unreal engine 5", or "masterpiece".
   - Instead, describe actual lighting (e.g., harsh low-angle sunlight, amber rim light), rich surface textures (e.g., weathered paint, dusty windshield glass), camera perspective (e.g., dynamic low-angle shot looking up), and environmental atmosphere.
4. OUTPUT FORMAT:
   - Exactly ONE paragraph, 60-95 words.
   - Output ONLY the prompt text. No quotes, no preamble, no markdown headers.`;

export async function enhancePrompt(prompt: string, signal?: AbortSignal): Promise<string> {
  const trimmed = prompt.trim();
  if (!trimmed) return prompt;

  // 1. Direct Groq API (client-side, runs on Vercel without a backend server)
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: "openai/gpt-oss-20b",
        messages: [
          {
            role: "system",
            content: ENHANCE_SYSTEM_PROMPT,
          },
          {
            role: "user",
            content: trimmed,
          },
        ],
        max_tokens: 2048,
        temperature: 0.5,
      }),
      signal,
    });

    if (res.ok) {
      const completion = (await res.json()) as {
        choices?: Array<{ message?: { content?: string } }>;
      };
      let text = completion.choices?.[0]?.message?.content?.trim();
      if (text) {
        text = text.replace(/^["'“”«»]+|["'“”«»]+$/g, "").trim();
        return text;
      }
    }
  } catch (err: unknown) {
    if (signal?.aborted) throw err;
  }

  // 2. Local server proxy fallback (if available)
  try {
    const res = await fetch("/api/enhance-prompt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: trimmed }),
      signal,
    });
    if (res.ok) {
      const data = (await res.json()) as { enhancedPrompt?: string };
      if (data.enhancedPrompt?.trim()) {
        return data.enhancedPrompt.trim();
      }
    }
  } catch (err: unknown) {
    if (signal?.aborted) throw err;
  }

  // Graceful fallback to original prompt
  return trimmed;
}
