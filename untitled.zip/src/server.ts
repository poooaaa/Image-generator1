import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";
import { ENHANCE_SYSTEM_PROMPT } from "./lib/image-generator";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isH3SwallowedErrorBody(body)) return response;

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

function isH3SwallowedErrorBody(body: string): boolean {
  try {
    const payload = JSON.parse(body) as { unhandled?: unknown; message?: unknown };
    return payload.unhandled === true && payload.message === "HTTPError";
  } catch {
    return false;
  }
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const url = new URL(request.url);
      if (url.pathname === "/api/lexica-feed" || url.pathname === "/api/bing-feed") {
        try {
          const res = await fetch("https://lexica.art/", {
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
              Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
              "Accept-Language": "en-US,en;q=0.9",
            },
          });
          const text = await res.text();
          return new Response(text, {
            status: res.status,
            headers: {
              "Content-Type": "text/html; charset=utf-8",
              "Access-Control-Allow-Origin": "*",
            },
          });
        } catch {
          return new Response("", {
            status: 200,
            headers: {
              "Content-Type": "text/html; charset=utf-8",
              "Access-Control-Allow-Origin": "*",
            },
          });
        }
      }

      if (url.pathname === "/api/generate-image") {
        if (request.method === "OPTIONS") {
          return new Response(null, {
            status: 204,
            headers: {
              "Access-Control-Allow-Origin": "*",
              "Access-Control-Allow-Methods": "POST, OPTIONS",
              "Access-Control-Allow-Headers": "Content-Type, Authorization",
            },
          });
        }
        try {
          const body = (await request.json().catch(() => ({}))) as {
            prompt?: string;
          };
          const prompt = body?.prompt || "";
          const authHeader = request.headers.get("authorization") || "Bearer 12345678";

          const workerRes = await fetch("https://ai-image.pooo79886.workers.dev", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: authHeader,
            },
            body: JSON.stringify({ prompt }),
          });

          if (!workerRes.ok) {
            return new Response(
              JSON.stringify({ error: `Worker API error: ${workerRes.status}` }),
              {
                status: workerRes.status,
                headers: {
                  "Content-Type": "application/json",
                  "Access-Control-Allow-Origin": "*",
                },
              },
            );
          }

          const arrayBuffer = await workerRes.arrayBuffer();
          return new Response(arrayBuffer, {
            status: 200,
            headers: {
              "Content-Type": workerRes.headers.get("content-type") || "image/jpeg",
              "Access-Control-Allow-Origin": "*",
            },
          });
        } catch (e: unknown) {
          const message = e instanceof Error ? e.message : "Failed to generate image via proxy";
          return new Response(JSON.stringify({ error: message }), {
            status: 500,
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*",
            },
          });
        }
      }

      if (url.pathname === "/api/enhance-prompt") {
        if (request.method === "OPTIONS") {
          return new Response(null, {
            status: 204,
            headers: {
              "Access-Control-Allow-Origin": "*",
              "Access-Control-Allow-Methods": "POST, OPTIONS",
              "Access-Control-Allow-Headers": "Content-Type, Authorization",
            },
          });
        }
        try {
          const body = (await request.json().catch(() => ({}))) as {
            prompt?: string;
          };
          const rawPrompt = body?.prompt?.trim() || "";
          if (!rawPrompt) {
            return new Response(JSON.stringify({ error: "Prompt is required" }), {
              status: 400,
              headers: { "Content-Type": "application/json" },
            });
          }

          const groqApiKey =
            process.env.GROQ_API_KEY || "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";

          const groqRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${groqApiKey}`,
            },
            body: JSON.stringify({
              model: "openai/gpt-oss-20b",
              messages: [
                {
                  role: "system",
                  content: ENHANCE_SYSTEM_PROMPT,
                },
                {
                  role: "user",
                  content: rawPrompt,
                },
              ],
              max_tokens: 2048,
              temperature: 0.5,
            }),
          });

          if (!groqRes.ok) {
            const errData = await groqRes.text();
            console.error("Groq enhancement error:", errData);
            return new Response(
              JSON.stringify({ enhancedPrompt: rawPrompt, warning: "Groq enhancement failed" }),
              {
                status: 200,
                headers: {
                  "Content-Type": "application/json",
                  "Access-Control-Allow-Origin": "*",
                },
              },
            );
          }

          const completion = (await groqRes.json()) as {
            choices?: Array<{ message?: { content?: string } }>;
          };
          let enhanced = completion.choices?.[0]?.message?.content?.trim() || rawPrompt;
          enhanced = enhanced.replace(/^["'“”«»]+|["'“”«»]+$/g, "").trim();

          return new Response(JSON.stringify({ enhancedPrompt: enhanced }), {
            status: 200,
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*",
            },
          });
        } catch (e: unknown) {
          const message = e instanceof Error ? e.message : "Enhancement failed";
          return new Response(JSON.stringify({ error: message }), {
            status: 500,
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*",
            },
          });
        }
      }

      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      return await normalizeCatastrophicSsrResponse(response);
    } catch (error) {
      console.error(error);
      return new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }
  },
};
