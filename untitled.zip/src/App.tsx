import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { MasonryGallery } from "@/components/MasonryGallery";
import { PromptText } from "@/components/PromptText";
import { generateImage, enhancePrompt, type GeneratedImage } from "@/lib/image-generator";

export default function App() {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    let interval: number | undefined;
    if (isGenerating) {
      setElapsed(0);
      interval = window.setInterval(() => {
        setElapsed((sec) => sec + 1);
      }, 1000);
    } else {
      setElapsed(0);
    }
    return () => {
      if (interval) window.clearInterval(interval);
    };
  }, [isGenerating]);

  const handleGenerate = async () => {
    const trimmed = prompt.trim();
    if (!trimmed) {
      setErrorMsg("Silakan ketik deskripsi gambar terlebih dahulu.");
      return;
    }

    setErrorMsg(null);
    setIsGenerating(true);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      // 1. Enchant prompt using Groq AI into detailed English
      const enchantedPrompt = await enhancePrompt(trimmed, controller.signal);

      // 2. Generate image using the enchanted prompt
      const { url } = await generateImage(enchantedPrompt, "12345678", controller.signal);
      const newImage: GeneratedImage = {
        id: "gen-" + Date.now(),
        url,
        prompt: enchantedPrompt,
        createdAt: Date.now(),
      };
      setGeneratedImages((prev) => [newImage, ...prev]);
      setPrompt("");
    } catch (err: unknown) {
      if (!controller.signal.aborted) {
        const message =
          err instanceof Error ? err.message : "Gagal membuat gambar. Silakan coba lagi.";
        setErrorMsg(message);
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  return (
    <main className="mx-auto max-w-3xl px-4 py-8 md:py-12">
      <section aria-label="Generate gambar">
        <textarea
          rows={3}
          value={prompt}
          onChange={(e) => {
            setPrompt(e.target.value);
            if (errorMsg) setErrorMsg(null);
          }}
          disabled={isGenerating}
          aria-label="Deskripsikan gambar"
          placeholder="Describe the image you want..."
          className="block w-full resize-none rounded-xl border border-zinc-700 bg-zinc-900 px-4 py-3.5 text-sm text-zinc-100 placeholder-zinc-500 outline-none focus:outline-none focus:ring-0 focus:border-zinc-700 disabled:opacity-70"
        />

        <Button
          variant="generate"
          type="button"
          onClick={handleGenerate}
          disabled={isGenerating}
          className="mt-3 h-10 w-full rounded-lg font-semibold flex items-center justify-center cursor-pointer disabled:cursor-not-allowed"
        >
          {isGenerating ? "Generating Image..." : "Generate Image ≥15s"}
        </Button>

        {errorMsg && <p className="mt-2 text-xs text-rose-400 font-medium">{errorMsg}</p>}
      </section>

      {/* Generating Loader Card matching HTML reference */}
      {isGenerating && (
        <section
          aria-label="Proses pembuatan gambar"
          className="mt-6 border border-zinc-700/80 bg-zinc-900 p-6 text-center rounded-none shadow-md"
        >
          <img src="/loading.png" alt="Memuat..." className="size-12 animate-spin mx-auto mb-3" />
          <p className="text-sm font-medium text-zinc-200">Generating image...</p>
          <p className="text-xs text-zinc-400 mt-1">
            Proses memakan waktu sekitar ≥15 detik ({elapsed}s)
          </p>
        </section>
      )}

      {/* Generated Images Showcase with Download Link */}
      {generatedImages.length > 0 && (
        <section aria-label="Hasil generate gambar" className="mt-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Hasil Generate ({generatedImages.length})
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {generatedImages.map((img) => (
              <div
                key={img.id}
                className="overflow-hidden border border-zinc-700/80 bg-[#111827] rounded-none shadow-md flex flex-col justify-between"
              >
                <div>
                  <img
                    src={img.url}
                    alt={img.prompt}
                    className="block w-full h-auto object-cover rounded-none bg-zinc-800"
                  />
                  <PromptText text={img.prompt} />
                </div>
                <a
                  href={img.url}
                  download="ai-image.jpg"
                  className="block py-2 px-3 text-xs text-center font-medium bg-[#1f2937] text-white hover:bg-[#374151] transition-colors rounded-none"
                >
                  Download
                </a>
              </div>
            ))}
          </div>
        </section>
      )}

      <MasonryGallery />
    </main>
  );
}
