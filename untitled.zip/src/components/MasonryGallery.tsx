import { useCallback, useEffect, useRef, useState } from "react";
import { fetchFeed, nextSeed, type GalleryImage } from "@/lib/gallery-feed";

const LOADING_IMAGE = "/loading.png";

function getRandomStartOffset(): number {
  // Randomizing initial offset avoids Bing's hardcoded seed=X&offset=0 cached duplicate batch
  return Math.floor(Math.random() * 45) + 1;
}

export function MasonryGallery() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const sentinel = useRef<HTMLDivElement>(null);
  const seeds = useRef(new Set<number>());
  const offset = useRef(getRandomStartOffset());
  const busy = useRef(false);
  const controller = useRef<AbortController | null>(null);
  const mounted = useRef(false);
  const seen = useRef(new Set<string>());

  const loadMore = useCallback(async () => {
    if (busy.current || !mounted.current) return;
    busy.current = true;
    setLoading(true);
    setErrorMsg(null);

    const abort = new AbortController();
    controller.current = abort;
    const timeout = window.setTimeout(() => abort.abort(), 10000);

    try {
      let page = offset.current;
      let fetchedBatch: GalleryImage[] = [];
      let attempts = 0;

      while (attempts < 2 && fetchedBatch.length === 0) {
        attempts++;
        const seed = nextSeed(seeds.current);
        const result = await fetchFeed(seed, page, abort.signal);
        page = result.nextOffset;
        offset.current = result.nextOffset;
        const fresh = result.images.filter((image) => !seen.current.has(image.src));
        if (fresh.length > 0) {
          fetchedBatch = fresh;
          break;
        }
      }

      if (fetchedBatch.length === 0) {
        throw new Error("Gagal memuat galeri gambar. Silakan coba lagi.");
      }

      fetchedBatch.forEach((image) => seen.current.add(image.src));

      if (mounted.current) {
        setImages((previous) => [...previous, ...fetchedBatch]);
      }
    } catch (err: unknown) {
      if (mounted.current && images.length === 0) {
        const message =
          err instanceof Error ? err.message : "Gagal memuat galeri gambar. Silakan coba lagi.";
        setErrorMsg(message);
      }
    } finally {
      window.clearTimeout(timeout);
    }

    await new Promise((resolve) => window.setTimeout(resolve, 300));
    if (mounted.current) {
      setLoading(false);
    }
    busy.current = false;
  }, [images.length]);

  useEffect(() => {
    mounted.current = true;
    void loadMore();
    return () => {
      mounted.current = false;
      controller.current?.abort();
    };
  }, []);

  useEffect(() => {
    const node = sentinel.current;
    if (!node || loading) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) void loadMore();
      },
      { rootMargin: "500px 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [loadMore, loading, images.length]);

  return (
    <section className="pt-6" aria-label="Galeri Gambar">
      {/* Main gallery container with 2 rounded top corners (rounded-t-2xl) and handle bar */}
      <div
        className={`w-full ${images.length === 0 ? "min-h-[320px] sm:min-h-[480px]" : "min-h-[550px]"} rounded-t-2xl rounded-b-none border-t border-zinc-700/80 bg-[#24242c] p-4 sm:p-6 shadow-lg flex flex-col justify-between`}
      >
        <div className="flex-1 flex flex-col">
          {/* Subtle horizontal gray handle bar at top center */}
          <div className="mx-auto mb-4 sm:mb-6 h-1.5 w-16 rounded-full bg-zinc-400/80" />

          {/* Loading animation positioned ~7% lower (pt-24 sm:pt-28) */}
          {images.length === 0 && loading && (
            <div className="flex flex-col items-center justify-start pt-24 pb-12 sm:pt-28 sm:pb-16">
              <img
                src={LOADING_IMAGE}
                alt="Memuat..."
                className="size-14 animate-spin motion-reduce:animate-none block"
              />
            </div>
          )}

          {/* Render loaded images in native CSS columns per RULE[AGENTS_md] */}
          {images.length > 0 && (
            <div className="columns-2 md:columns-3 gap-3 md:gap-4 [column-fill:_balance]">
              {images.map((image, idx) => (
                <div key={image.id + idx} className="mb-3 md:mb-4 break-inside-avoid">
                  <GalleryThumbnail image={image} index={idx} />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Loading indicator at the bottom sentinel area when loading more batches */}
        <div
          ref={sentinel}
          className="flex min-h-16 flex-col items-center justify-center gap-2 pt-6 pb-2"
          role="status"
          aria-live="polite"
        >
          {loading && images.length > 0 && (
            <img
              src={LOADING_IMAGE}
              alt="Memuat..."
              className="size-12 animate-spin motion-reduce:animate-none block"
            />
          )}
          {errorMsg && images.length === 0 && (
            <div className="text-center py-12">
              <span className="text-sm text-zinc-400 block mb-3">{errorMsg}</span>
              <button
                type="button"
                onClick={() => void loadMore()}
                className="px-4 py-2 text-xs font-semibold rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-200 transition-colors"
              >
                Coba Lagi
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function GalleryThumbnail({ image, index }: { image: GalleryImage; index: number }) {
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);

  if (failed) return null;

  return (
    <div
      className={`relative w-full overflow-hidden border border-zinc-700/80 bg-zinc-900 rounded-none ${
        !loaded ? "min-h-[180px] sm:min-h-[240px] bg-zinc-800 animate-pulse" : ""
      }`}
    >
      <img
        src={image.src}
        alt={image.alt}
        width={image.width}
        height={image.height}
        loading={index < 4 ? "eager" : "lazy"}
        decoding="async"
        referrerPolicy="no-referrer"
        onLoad={() => setLoaded(true)}
        onError={() => setFailed(true)}
        className={`block h-auto w-full transition-opacity duration-300 ${loaded ? "opacity-100" : "opacity-0"}`}
      />
    </div>
  );
}
