import { useEffect, useRef, useState } from "react";

interface PromptTextProps {
  text: string;
}

/**
 * Truncates text strictly to a maximum of 10 lines using pure JavaScript DOM measurement.
 * Lines 11 and onwards are omitted from the text content and replaced with "..." at line 10.
 */
export function PromptText({ text }: PromptTextProps) {
  const containerRef = useRef<HTMLParagraphElement>(null);
  const [clampedText, setClampedText] = useState(text);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    function recalculate() {
      if (!el) return;
      // Put original text first to measure natural height
      el.textContent = text;

      const computed = window.getComputedStyle(el);
      let lh = parseFloat(computed.lineHeight);
      if (!lh || Number.isNaN(lh)) {
        const fs = parseFloat(computed.fontSize) || 13;
        lh = fs * 1.4;
      }

      // Exact pixel boundary for 10 lines
      const maxAllowedHeight = Math.ceil(lh * 10);

      // If it fits in 10 lines or less, display full text
      if (el.scrollHeight <= maxAllowedHeight + 1) {
        setClampedText(text);
        return;
      }

      // Exceeds 10 lines: binary-search words to fill exactly up to line 10 with "..."
      const words = text.split(/\s+/);
      let low = 0;
      let high = words.length;
      let best = text;

      while (low <= high) {
        const mid = Math.floor((low + high) / 2);
        const testCandidate = words.slice(0, mid).join(" ") + "...";
        el.textContent = testCandidate;

        if (el.scrollHeight <= maxAllowedHeight + 1) {
          best = testCandidate;
          low = mid + 1; // Try fitting more words up to line 10
        } else {
          high = mid - 1; // Exceeded line 10, back off
        }
      }

      setClampedText(best);
      el.textContent = best;
    }

    recalculate();

    if (typeof ResizeObserver !== "undefined") {
      const ro = new ResizeObserver(() => {
        recalculate();
      });
      ro.observe(el);
      return () => ro.disconnect();
    }
  }, [text]);

  return (
    <p
      ref={containerRef}
      title={text}
      className="p-3 text-[13px] text-zinc-200/90 leading-snug break-words"
    >
      {clampedText}
    </p>
  );
}
