import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { PromptText } from "@/components/PromptText";

describe("PromptText", () => {
  it("renders text without crashing", () => {
    render(<PromptText text="A beautiful cat in a park" />);
    expect(screen.getByText("A beautiful cat in a park")).toBeInTheDocument();
  });
});
