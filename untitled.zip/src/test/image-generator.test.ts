import { describe, expect, it, vi } from "vitest";
import { generateImage, enhancePrompt, API_URL, DEFAULT_API_KEY } from "@/lib/image-generator";

describe("Image Generator", () => {
  it("rejects empty prompt", async () => {
    await expect(generateImage("   ")).rejects.toThrow("Masukkan deskripsi gambar terlebih dahulu");
  });

  it("calls the worker endpoint with Authorization Bearer header", async () => {
    const mockBlob = new Blob(["fake-image-bytes"], { type: "image/jpeg" });
    const originalFetch = globalThis.fetch;
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      blob: async () => mockBlob,
    });
    globalThis.fetch = fetchMock;

    try {
      const res = await generateImage("cat", "12345678");
      expect(fetchMock).toHaveBeenCalledWith(
        API_URL,
        expect.objectContaining({
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${DEFAULT_API_KEY}`,
          },
          body: JSON.stringify({ prompt: "cat" }),
        }),
      );
      expect(res.url).toBeDefined();
    } finally {
      globalThis.fetch = originalFetch;
    }
  });

  it("enforces prompt enhancement with fallback on error", async () => {
    const originalFetch = globalThis.fetch;
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        enhancedPrompt:
          "A majestic golden retriever running in a sunny park with cinematic lighting",
      }),
    });
    globalThis.fetch = fetchMock;

    try {
      const enhanced = await enhancePrompt("anjing di taman");
      expect(enhanced).toBe(
        "A majestic golden retriever running in a sunny park with cinematic lighting",
      );
    } finally {
      globalThis.fetch = originalFetch;
    }
  });
});
