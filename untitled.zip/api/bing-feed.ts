type ApiRequest = {
  query?: Record<string, string | undefined>;
};

type ApiResponse = {
  setHeader: (name: string, value: string) => void;
  status: (code: number) => {
    send: (body: string) => void;
    json: (body: unknown) => void;
  };
};

export default async function handler(req: ApiRequest, res: ApiResponse) {
  const seed = req.query?.seed || "1";
  const offset = req.query?.offset || "1";
  const bingUrl = `https://www.bing.com/images/create/async/categoryfeedpage?category=all&seed=${seed}&pageOffset=${offset}&language=en`;

  try {
    const response = await fetch(bingUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
    });

    const text = await response.text();
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    res.status(response.status).send(text);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to fetch Bing feed";
    res.status(500).json({ error: message });
  }
}
